from __future__ import annotations

import struct
import zlib
from pathlib import Path
from typing import Any, Dict, Optional


def verify_wav(
    path: str | Path,
    *,
    expected_rate: Optional[int] = None,
    expected_bits: Optional[int] = None,
    expected_channels: Optional[int] = None,
    expected_samples: Optional[int] = None,
    acquired_samples: Optional[int] = None,
    processed_samples: Optional[int] = None,
    written_samples: Optional[int] = None,
    boundary_discarded_samples: int = 0,
    reference_crc32: Optional[int] = None,
) -> Dict[str, Any]:
    """Read and check a PCM RIFF/WAVE file without treating a post-read CRC as source proof."""
    p = Path(path)
    report: Dict[str, Any] = {
        "path": str(p), "exists": p.is_file(), "readable": False,
        "structure": "FAIL", "sample_accounting": "NOT AVAILABLE",
        "payload_crc32": "NOT AVAILABLE" if reference_crc32 is None else "FAIL",
        "status": "FAIL", "errors": [],
    }
    if not p.is_file():
        report["errors"].append("file does not exist")
        return report

    try:
        size = p.stat().st_size
        with p.open("rb") as f:
            head = f.read(12)
            if len(head) != 12 or head[:4] != b"RIFF" or head[8:12] != b"WAVE":
                raise ValueError("invalid RIFF/WAVE header")
            riff_size = struct.unpack_from("<I", head, 4)[0]
            if riff_size + 8 != size:
                raise ValueError(f"RIFF size {riff_size + 8} does not match file size {size}")
            fmt = None
            data_offset = data_size = None
            offset = 12
            while offset + 8 <= size:
                f.seek(offset)
                chunk = f.read(8)
                if len(chunk) != 8:
                    raise ValueError("truncated chunk header")
                tag, chunk_size = chunk[:4], struct.unpack_from("<I", chunk, 4)[0]
                payload_offset = offset + 8
                end = payload_offset + chunk_size
                if end > size:
                    raise ValueError(f"{tag!r} chunk exceeds file boundary")
                if tag == b"fmt ":
                    if chunk_size < 16:
                        raise ValueError("fmt chunk shorter than PCM format header")
                    f.seek(payload_offset)
                    raw_fmt = f.read(16)
                    audio_format, channels, rate, byte_rate, align, bits = struct.unpack("<HHIIHH", raw_fmt)
                    fmt = {"audio_format": audio_format, "channels": channels, "sample_rate": rate,
                           "byte_rate": byte_rate, "block_align": align, "bits_per_sample": bits}
                elif tag == b"data":
                    if data_offset is not None:
                        raise ValueError("multiple data chunks are not supported")
                    data_offset, data_size = payload_offset, chunk_size
                offset = end + (chunk_size & 1)
                if offset > size:
                    raise ValueError(f"{tag!r} chunk is missing its RIFF padding byte")
            if fmt is None or data_offset is None or data_size is None:
                raise ValueError("required fmt or data chunk missing")
            if fmt["audio_format"] != 1:
                raise ValueError(f"unsupported WAVE encoding {fmt['audio_format']}; PCM required")
            if fmt["block_align"] != fmt["channels"] * fmt["bits_per_sample"] // 8:
                raise ValueError("block alignment is inconsistent with channels and bit depth")
            if data_size % fmt["block_align"]:
                raise ValueError("data chunk is not an integral number of frames")
            checks = (("sample_rate", expected_rate), ("bits_per_sample", expected_bits), ("channels", expected_channels))
            for key, expected in checks:
                if expected is not None and fmt[key] != expected:
                    raise ValueError(f"{key} {fmt[key]} does not match expected {expected}")
            f.seek(data_offset)
            remaining = data_size
            crc = 0
            while remaining:
                block = f.read(min(1024 * 1024, remaining))
                if not block:
                    raise ValueError("PCM payload is truncated during readback")
                crc = zlib.crc32(block, crc)
                remaining -= len(block)
        frames = data_size // fmt["block_align"]
        report.update({"readable": True, "structure": "PASS", "file_size_bytes": size,
                       "riff_size_bytes": riff_size + 8, "data_size_bytes": data_size,
                       "sample_rate": fmt["sample_rate"], "bits_per_sample": fmt["bits_per_sample"],
                       "channels": fmt["channels"], "sample_frames": frames,
                       "readback_crc32": f"{crc & 0xffffffff:08x}"})
        if reference_crc32 is not None:
            ref = int(reference_crc32, 16) if isinstance(reference_crc32, str) else int(reference_crc32)
            report["payload_crc32"] = "PASS" if (crc & 0xffffffff) == ref else "FAIL"
        if expected_samples is not None:
            expected_ok = frames == expected_samples
            counters = [v for v in (acquired_samples, processed_samples, written_samples) if v is not None]
            counters_ok = all(abs(int(v) - frames) <= boundary_discarded_samples for v in counters)
            report["sample_accounting"] = "PASS" if expected_ok and counters_ok else "FAIL"
            report["expected_samples"] = expected_samples
            report["sample_counters"] = {"acquired": acquired_samples, "processed": processed_samples,
                                         "written": written_samples, "boundary_discarded": boundary_discarded_samples}
        required_ok = report["structure"] == "PASS" and report["sample_accounting"] == "PASS" and report["payload_crc32"] != "FAIL"
        report["status"] = "PASS" if required_ok else "UNVERIFIED" if report["sample_accounting"] == "NOT AVAILABLE" else "FAIL"
        if reference_crc32 is None:
            report["crc_note"] = "post-read CRC is recorded for reference only; no pre-write CRC was available"
    except (OSError, ValueError, struct.error) as exc:
        report["errors"].append(str(exc))
    return report
